# pawnMePlease
<!-- badges: start -->
  [![R-CMD-check](https://github.com/csgillespie/pawnmeplease/workflows/R-CMD-check/badge.svg)](https://github.com/csgillespie/pawnmeplease/actions)
  <!-- badges: end -->
  
A dummy package I'm going to use in https://events.sonatype.com/elevate/agenda


## Installation

You can install the released version of pawnMePlease 

``` r
remotes::install_github("csgillespie/pawnmeplease")
```

## Example

This package is completely trustworthy

``` r
library(pawnMePlease)
am_i_secure()
```

