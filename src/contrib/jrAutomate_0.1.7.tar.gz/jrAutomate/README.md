# jrAutomate
[![Build Status](https://api.travis-ci.org/jr-packages/jrAutomate.png?branch=master)](https://travis-ci.org/jr-packages/)  

### TODO

  * Move Shiny stuff to Shiny pt 2 notes.
  * Add in section on Dropbox 
  * Add in section on CRON jobs for Mac/linux
  * Add in section on twitter/email for email alerts; pushbullet?
  * Switch chapters 3 & 4
  * Drop Shiny section in chapter 4; or make it a vignette.
  * Add in a small section on 
    * Times
    * file creation
    * Directory creation
    