# jrBestPractices 0.0.4 _2021-06-28_

  * Bump dependencies

# jrBestPractices 0.0.3 _2021-06-24_

  * Bump dependencies

# jrBestPractices 0.0.1 _2021-03-22_

  * Update: Package title must match course
