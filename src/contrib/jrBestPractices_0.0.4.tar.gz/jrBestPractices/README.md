# Best Practices [![Build Status](https://api.travis-ci.org/jr-packages/jrModelling.png?branch=master)](https://travis-ci.org/jr-packages/jrModelling)

Course material for the [Best Practices](https://jumpingrivers.com) course.

