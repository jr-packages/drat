# jrGgplot2Bio 0.1.7 _2021-02-04_
  * Rename Beauty gender variable to sex
  * Add {gghighlight} to DESCRIPTION

# jrGgplot2Bio 0.1.6 _2021-01-03_
  * Initialse
