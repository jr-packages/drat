# jrGgplot2 0.1.19 _2020-09-18_
  * Change pkg title
  * Add NEWS.md
  * Fix lintr errors
