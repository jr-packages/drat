## ----include = FALSE----------------------------------------------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)

