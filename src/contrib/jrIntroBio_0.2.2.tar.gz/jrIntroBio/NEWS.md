# jrIntroBio 0.2.2 _2021-01-02_

  * Initialise
