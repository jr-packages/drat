# jrIntroBio
[![Build Status](https://api.travis-ci.org/jr-packages/jrIntroBio.png?branch=master)](https://travis-ci.org/jr-packages/jrIntroBio)

Biology focussed introduction for the Crick Institute
