## ----include = FALSE----------------------------------------------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE, cache = FALSE)

## ---- echo = TRUE, eval = TRUE, warning = FALSE, message = FALSE--------------
library("ggplot2")
data(yeast, package = "jrIntroBio")

## ----label = "scatter_simple", fig.margin = TRUE, fig.cap="A basic scatter plot.", echo = TRUE----
ggplot(yeast, aes(x = mcg, y = gvh)) +
  geom_point()

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(yeast, aes(x = mcg, y = gvh)) +
#    geom_point() +
#    labs(x = "McGeoch's method",
#         y = "von Heijne's method",
#         title = "Correlation of signal sequence detection measures")

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(yeast, aes(x = mcg, y = gvh)) +
#    geom_point() +
#    labs(x = "McGeoch's method",
#         y = "von Heijne's method") +
#    xlim(0, 1) +
#    ylim(0, 1)

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(yeast, aes(x = mcg, y = gvh)) +
#    geom_point(colour = "red") +
#    labs(x = "McGeoch's method",
#         y = "von Heijne's method") +
#    xlim(0, 1) +
#    ylim(0, 1)

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(yeast, aes(x = mcg, y = gvh)) +
#    geom_point(aes(colour = class)) +
#    labs(x = "McGeoch's method",
#         y = "von Heijne's method") +
#    xlim(0, 1) +
#    ylim(0, 1)
#  
#  # need the aes() function because we are mapping
#  # a variable in the data set to an aesthetic

## ---- label = "double", fig.cap = "A scatter plot and bar chart as a target for these exercises.", echo = FALSE, fig.margin = TRUE----
ggplot(yeast, aes(x = mcg, y = gvh)) +
  geom_point(aes(colour = class)) +
  labs(x = "McGeoch's method",
       y = "von Heijne's method") +
  xlim(0, 1) +
  ylim(0, 1)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  ggplot(yeast, aes(x = mcg)) +
#    geom_histogram()

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(yeast, aes(x = mcg)) +
#    geom_histogram(binwidth = 0.02)

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(yeast, aes(x = mcg, fill = class)) +
#    geom_histogram(binwidth = 0.02)
#  # different colour for each fill

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(yeast, aes(x = mcg)) +
#    geom_histogram(binwidth = 0.02, alpha = 0.02)
#  # alpha controls the transparency

## ---- warning = FALSE, fig.width=6, fig.height=3, fig.cap = "Density plots of McGeoch's method coloured by class"----
ggplot(yeast, aes(x = mcg, fill = class)) +
  geom_density(binwidth = 0.02, alpha = 0.2)

## ---- eval= FALSE, echo = TRUE------------------------------------------------
#  vignette("solutions3", package = "jrIntroBio")

