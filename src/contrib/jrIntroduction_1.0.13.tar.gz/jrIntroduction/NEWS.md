# jrIntroduction 1.0.13 _2021-01-02_

  * Initialise
