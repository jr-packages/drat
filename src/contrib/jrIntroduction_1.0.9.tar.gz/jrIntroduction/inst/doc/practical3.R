## ----include = FALSE----------------------------------------------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE, cache = FALSE)

## ---- echo = TRUE, eval = TRUE------------------------------------------------
library("ggplot2")
data(movies, package = "jrIntroduction")

## ---- eval = FALSE------------------------------------------------------------
#  g = ggplot(movies, aes(x = votes, y = rating)) +
#      geom_point()

## ---- eval = FALSE------------------------------------------------------------
#  g + labs(x = "No of Votes",
#           y = "Average IMDB Rating",
#           title = "No of Votes vs Average IMDB Rating")

## ---- eval = FALSE------------------------------------------------------------
#  g + ylim(0, 10)

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(movies, aes(x = year)) +
#      geom_histogram()

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(movies, aes(x = year)) +
#      geom_histogram(binwidth = 1)

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(movies, aes(x = classification)) +
#    geom_bar()

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(movies, aes(x = classification)) +
#      geom_bar(colour = "blue")

## ---- eval = TRUE, results = "hide"-------------------------------------------
colours()

## ---- eval = FALSE------------------------------------------------------------
#  ggplot(movies, aes(x = classification, fill = classification)) +
#      geom_bar()

## ---- eval= FALSE, echo = TRUE------------------------------------------------
#  vignette("solutions3", package = "jrIntroduction")

