# jrModellingBio 0.0.3 _2021-04-07_

  * Initialise
