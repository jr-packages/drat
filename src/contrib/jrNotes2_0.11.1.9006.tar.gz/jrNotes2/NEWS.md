# jrNotes2 (development version)
  * Testing

# jrNotes2 0.11.1 _2020-12-14_
  * Internal: Allow `provision_venv()` to create virtualenv in places other
    than just the `notes/` directory
   
