has_changed = function(i, fnames, templates) {
  fname1 = fnames[i]; template_file = templates[i]
  if (!file.exists(fname1) && !is_gitlab()) {
    fs::file_copy(template_file, fname1)
    msg_info(glue("Updating {fname1}"), padding = TRUE)
    return(invisible(TRUE))
  }

  d1 = digest::digest(readLines(fname1))
  d2 = digest::digest(readLines(template_file))
  if (d1 != d2) {
    if (!is_gitlab()) {
      msg_info(glue("Updating {fname1}"), padding = TRUE)
      fs::file_copy(template_file, fname1, overwrite = TRUE)
    }
    return(invisible(TRUE))
  }
  msg_success(fname1, padding = TRUE)
  return(invisible(FALSE))
}


get_project_name = function() {
  proj_name = system("git remote -v | head -n1 | awk '{print $2}' | sed 's/.*\\///' | sed 's/\\.git//'", #nolint
                     intern = TRUE) #nolint

  gsub("_notes", "", proj_name)
}

# Compare gitlab-ci files
get_runner_hash = function(fname) {
  line_break = "#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#"
  lines = readLines(fname)

  start = which(lines == line_break)[1]
  end = which(lines == line_break)[2]

  digest::digest(lines[start:end])
}

# Update gitlab runner
update_gitlab_ci = function(fname, template_fname) {
  line_break = "#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#"

  ## Extract template CI part
  lines = readLines(template_fname)

  start = which(lines == line_break)[1]
  end = which(lines == line_break)[2]
  template_lines = lines[start:end]

  ## Remove template part from current gitlab
  lines = readLines(fname)
  start = which(lines == line_break)[1]
  end = which(lines == line_break)[2]
  template_lines = c(template_lines, lines[end + 1])

  lines = lines[-(start:length(lines))] #nolint
  lines = c(lines, template_lines)
  f = file(fname, "w")
  on.exit(close(f))
  cat(lines, file = f, sep = "\n")
}


check_gitlab_runner = function(fname, template) {
  if (!file.exists(fname)) {
    fs::file_copy(template, fname)
    msg_info("Updating gitlab-ci", padding = TRUE)
  } else if (get_runner_hash(fname) != get_runner_hash(template)) {
    if (is_gitlab()) {
      msg_error("gitlab-ci.yml has changed", padding = TRUE)
      return(FALSE)
    }
    update_gitlab_ci(fname, template)
    msg_info("gitlab-ci.yml has been updated", padding = TRUE)
  } else {
    msg_success(fname, padding = TRUE)
  }
  return(TRUE)
}

get_template_fnames = function(root_dir) {
  dir = system.file("template", package = "jrNotes2")
  template_files = list.files(dir, recursive = TRUE, full.names = TRUE, all.files = TRUE)
  sort(template_files)
}

check_notes_references = function() {
  root_dir = get_root_dir()
  refs_path = file.path(root_dir, "notes/references.bib")
  if (file.exists(refs_path)) {
    msg_success("notes/references.bib", padding = TRUE)
  } else if (file.exists(file.path(root_dir, "notes"))) {
    msg_info("notes/references.bib is missing", padding = TRUE)
    dir = system.file("template", package = "jrNotes2")
    fs::file_copy(file.path(dir, "notes/references.bib"), refs_path)
    msg_success("Updating references.bib", padding = TRUE)
  }
  return(invisible(NULL))
}

get_root_dir = function(dir = ".") {
  if ("config.yml" %in% list.files(path = dir, all.files = TRUE)) {
    return(normalizePath(dir))
  }
  get_root_dir(dir = file.path("..", dir))
}

#' Checks notes files are the same as template
#'
#' Ensures that certain notes files are the same as the notes template.
#' These canonical files are identical for all notes, e.g. Makefiles,
#' main.Rmd.
#'
#' Typically this used by the gitlab-ci runner. The programming
#' language is inferred via \code{get_repo_language}.
#' @export
check_template = function() {
  if (Sys.getenv("CI_PROJECT_NAME") == "template") {
    # Feedback loop if we test template on it's on master
    return(invisible(NULL))
  }
  msg_start("Checking template files...check_template()")
  proj_name = get_project_name()

  # Ensure Rproj are given sensible names - not just notes.Rproj
  # Sort to match template
  fnames = sort(c(glue("notes/notes_{proj_name}.Rproj"),
                  glue("slides/slides_{proj_name}.Rproj"),
                  "Makefile", ".gitignore",
                  "notes/Makefile", "notes/main.Rmd",
                  "slides/Makefile"))
  root_dir = get_root_dir()
  fnames = file.path(root_dir, fnames)
  template_fnames = get_template_fnames(root_dir)

  if (!file.exists(file.path(root_dir, "notes"))) {
    notes = stringr::str_detect(fnames, pattern = "notes")
    template_fnames = template_fnames[!notes]
    fnames  = fnames[!notes]
  }
  if (!file.exists(file.path(root_dir, "slides"))) {
    slides = stringr::str_detect(fnames, pattern = "slides")
    template_fnames = template_fnames[!slides]
    fnames = fnames[!slides]
  }
  runner_check = TRUE
  #  runner_check = check_gitlab_runner(file.path(dir, ".gitlab-ci.yml"),
  #                                    file.path(template_repo_loc, ".gitlab-ci.yml"))

  # Compare files to template
  # Keep track of any differences
  changed = vapply(seq_along(fnames), has_changed,
                   fnames, template_fnames, FUN.VALUE = logical(1))
  changed = any(changed)

  check_notes_references()
  if ((changed || isFALSE(runner_check)) &&
      nchar(Sys.getenv("GITLAB_CI")) != 0) {
    msg = glue::glue("Files differs from template repo. \\
          Either revert your changes or update the template. \\
          If you think you want to update the template, make a merge \\
          request and ask for feedback.")
    msg_error(msg)
  }

  if (length(list.files(pattern = "*\\.Rproj$", path = root_dir)) > 0L) {
    msg_error("Don't add Rproj files to the base directory.")
    changed = TRUE
  }

  if (file.exists(file.path(root_dir, "notes")) &&
      length(list.files(pattern = "*\\.Rproj$", path = file.path(root_dir, "notes"))) != 1L) {
    msg_error("There should only be a single Rproj file in notes/")
    changed = TRUE
  }

  if (file.exists(file.path(root_dir, "slides")) &&
      length(list.files(pattern = "*\\.Rproj$", path = file.path(root_dir, "slides"))) != 1L) {
    msg_error("There should only be a single Rproj file in slides/")
    changed = TRUE
  }

  if (isFALSE(changed)) msg_success("Template files look good")
  return(invisible(NULL))
}
