#' @title Create and use a virtualenv with python packages listed in config.yml
#' installed
#'
#' @description Create and use a virtualenv with python packages listed in config.yml
#' @param venv_dir The directory in which to create the virtualenv (typically
#' "notes" or "slides")
#' installed
#' @export
provision_venv = function(venv_dir = "notes") {

  if (get_repo_language() != "python") {
    cli::cli_alert_info("No venv created...not python")
    return(invisible(NULL))
  }

  ## Get python packages listed in config.yml
  pkgs = get_python_pkg_name()

  ## If no python packages listed don't do anything
  ## Edge case - useful when starting notes
  if (length(pkgs) == 0L) {
    cli::cli_alert_info("No venv created...no pkgs specified")
    return(invisible(NULL))
  }
  msg_start("Creating a venv...provision_venv()")
  venv_path = file.path(get_root_dir(), venv_dir, "venv")
  ## If a virtualenv hasn't already been made, make it
  if (!dir.exists(venv_path)) {
    create_venv(pkgs, venv_dir)
  }

  ## Activate the virtualenv
  reticulate::use_virtualenv(venv_path)
  Sys.setenv("RETICULATE_PYTHON" = file.path(venv_path, "/bin/python"))
}

create_venv = function(pkgs, venv_dir) {
  ## Unique in case jrpytests or jupytext listed in config.yml
  pkgs = unique(c(pkgs, "jrpytests", "jupytext"))

  # if running on the gitlab pipelines, we want to point the package to the local one where
  # possible
  if (is_gitlab()) {
    pkgs = match_with_local_pkgs(pkgs)
  }

  ## By default reticulate creates virtualenvs in ~/.virtualenv
  ## To change where the virtualenv is created we have to use
  ## the WORKON_HOME environment variable
  Sys.setenv(WORKON_HOME = file.path(get_root_dir(), venv_dir))

  ## Create the virtualenv
  reticulate::virtualenv_install(
    envname = "venv",
    python = Sys.which("python3"),
    packages = pkgs
  )
  return(invisible(NULL))
}

#' match with local pkgs
#'
#' intended for gitlab runners, will attempt to find the local build version
#' of required packages and substitute them into the list of targets for
#' the virtual env install
#' @param pkgs vector of package names
#' @return vector of pkgs names, possibly including file paths
match_with_local_pkgs = function(pkgs) {
  local_pkgs = list.files(file.path(get_root_dir(), "ci_python_pkgs"))
  purrr::map_chr(pkgs, ~{
    match = stringr::str_detect(basename(local_pkgs), paste0("^", .x))
    if (any(match)) {
      local_pkgs[match]
    } else {
      .x
    }
  })
}
