tokenise = function() {
  msg_start("Creating tokens...tokenise()")
    fname = system.file("extdata", "extractor.tex",
                      package = "jrNotes2", mustWork = TRUE)

  file.copy(fname, to = "extractor.tex", overwrite = TRUE)
  file.copy("index.tex", "extractor-tmp.tex", overwrite = TRUE)
  system2("xelatex",
          args = c("'\\input extractor \\input extractor-tmp.tex'"),
          stdout = FALSE)
  msg_success("Tokens created")
}

globalVariables("text")
read_tokens = function() {
  tokens = utils::read.delim("extractor.csv", sep = "|",
                      header = FALSE,
                      col.names = c("X1", "X2", "X3"),
                      stringsAsFactors = FALSE)

  tibble::as_tibble(tokens)
}
