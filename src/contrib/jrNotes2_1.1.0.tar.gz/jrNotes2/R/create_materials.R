check_optipng = function() {
  optipng_status = Sys.which("optipng")
  if (nchar(optipng_status) == 0) {
    msg_error("optipng installation required - 'sudo apt install optipng'")
    return(invisible(NULL))
  }
}

## Updates index.md with the new png files
update_index_md = function() {
  cli::cli_alert_info("Updating index.md with new files")
  root = get_root_dir()

  ## Read in current index.md
  con = get_config()
  website_name = con$website$name
  course_website_dir = file.path(root, "website")
  (notes_materials = list.files(file.path(course_website_dir, "materials")))
  ## If no materials, exit
  if (length(notes_materials) == 0) {
    cli::cli_alert_warning("No material pngs found")
    return(invisible(NULL))
  }

  ## Determine where images are in the YAML
  index_md_path = file.path(course_website_dir, "index.md")
  index_md = readr::read_lines(index_md_path)
  images = stringr::str_detect(index_md, "^  images:")
  if (all(!images)) {
    cli::cli_alert_warning("No image section detected in index.md - adding one now")
    # Splice in a section at the end
    end_of_yaml = which(stringr::str_detect(index_md, "---"))[2] - 1
    new_lines = c("materials:", "  images:", "    - ", "")
    index_md = c(index_md[1:end_of_yaml],
                 new_lines,
                 index_md[(end_of_yaml + 1):length(index_md)])
    images = stringr::str_detect(index_md, "^  images:")
  }

  # Remove old entries and add in new ones
  images_line_number = which(images)
  images = stringr::str_detect(index_md[(images_line_number + 1):(length(index_md))], "^    - ")
  # Find the first line after the images
  to_start = images_line_number + which(!images)[1]

  new_index_lines = file.path("/course-details/materials", website_name, notes_materials)
  new_index_lines = paste0('    - "', new_index_lines, '"')
  new_index = c(index_md[1:images_line_number],
                new_index_lines,
                index_md[to_start:length(index_md)])
  if (new_index[length(new_index)] != "") new_index = c(new_index, "")

  readr::write_lines(new_index, index_md_path)
  cli::cli_alert_success("index.md updated")
  return(invisible(NULL))
}


#' A function used to extract pre-defined pages from
#' index.pdf and convert them into images
#' @importFrom pdftools pdf_convert pdf_length
#' @importFrom stringr str_split
#' @export
create_materials = function() {
  root_dir = get_root_dir()
  if (!file.exists(file.path(root_dir, "notes"))) return(invisible(NULL))

  msg_start("Creating materials...create_materials()")
  check_optipng()
  # Parse and extract numbers from pages
  con = get_config()
  pages = con$website$materials
  if (is.null(pages)) {
    msg_warning("No page numbers defined in config.yml")
    return(invisible(NULL))
  }
  pages = unlist(stringr::str_split(pages, ", "))
  pages = as.numeric(pages)
  if (pages[1] != 1 || pages[2] != 2) {
    msg_error("First two page numbers in config.yml should be 1 & 2")
    return(invisible(NULL))
  }

  # Extract root directory
  index_pdf = file.path(root_dir, "notes", "index.pdf")

  # Total number of pages in index.pdf
  total_pages = pdftools::pdf_length(index_pdf)
  if (any(pages > total_pages)) {
    msg_error(paste("Remove page numbers greater than", total_pages, "listed in config.yml"))
    return(invisible(NULL))
  }

  # Delete old pages then start from scratch
  materials_dir = file.path(root_dir, "website", "materials")
  if (file.exists(materials_dir)) fs::file_delete(materials_dir)
  fs::dir_create(materials_dir)

  # Generate vector of target file paths
  target_paths = file.path(materials_dir,
                           paste0("page", stringr::str_pad(pages, 2, pad = "0"), ".png"))

  # Convert parsed pdf pages to png's
  pdftools::pdf_convert(index_pdf, pages = pages, format = "png",
                        filenames = target_paths, dpi = 150)

  # Optimising the images using optipng
  for (page in target_paths) {
    system2("optipng", args = c("-o1", "-quiet", page))
    cli::cli_alert_success("Optimising {page}")
  }
  update_index_md()
  # Materials check
  msg_info("Remember to check the quality of the materials pages!")
  msg_success("Materials created!")
  return(invisible(NULL))
}
