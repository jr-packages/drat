# jrNotes2 1.1.3 _2021-03-12_
  * Feature: Build google-docs from Rmds

# jrNotes2 1.1.2 _2021-03-10_
  * Internal: Re-tidy description following {desc} update

# jrNotes2 1.1.1 _2021-03-05_
  * Feature: Add `notes_img_fname_check()` to check website featured img filenames
  * Feature: Add functionality to copy featured img's from notes to website repo

# jrNotes2 1.1.0 _2021-03-04_
  * Feature: Remove flake8 noqa's from code chunks

# jrNotes2 1.0.* _2021-02-28_
  * Bug: The {knitr} options in config.yml were ignored
  * Feature: Improved feedback when building the notes
  * Internal: Slightly more robust path construction
  * Feature: Update website/index.md with material file names
  * Bug: Use a venv to build python vignettes
  * Feature: Move `check_template()` to standard `render()` function
  * Feature: Different render types can can now be specified. Currently only jrPyVis
  * Feature: Alter `jrStyle.sty` to work for notes _without_ any code chunks
  * Feature: `main.Rmd` now called `index.Rmd`
  * Internal: Add docker pull before docker build in Makefile template
  * Bug: Remove old python .tar.gz pkgs to avoid caching issues
  * Bug: python template location
  * Internal: Add functionality in create_materials.R
  * Internal: Add `libpoppler-cpp-dev` to `deb_pkgs` in config.yml
  * Internal: Add `create_materials()` to `create_final_dir()`
  * Feature: Check python package Makefile template
  * Feature: Makefile dependency on vignette source in python packages
  * Bug: Updated root Makefile template for notes projects
  * Feature: Install local python packages on local machines
  * Feature: Language is no longer used by venv. Instead, just look at config for python dep
  * Bug: Local Python packages requires full path to install
  * Feature: Install local packages
  * Internal: Simplify extracting logical values from config
  * Bug: detect lintr in config file
  * Internal: Allow `provision_venv()` to create `virtualenv` in places other
    than just the `notes/` directory
   
