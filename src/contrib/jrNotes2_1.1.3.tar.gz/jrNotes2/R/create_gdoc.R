#' Read upcoming course details
#'
#' @importFrom yaml read_yaml
#' @rdname create_gdoc
get_upcoming_deets = function() {
  # client_id, client_name, course_date, vm_url, master_password
  yaml::read_yaml("upcoming_course.yml")
}

#' Construct filename for document
#'
#' @importFrom glue glue
#' @rdname create_gdoc
construct_gdoc_filename = function() {

  # Get course name from config
  course_name = get_config()$running

  # Get details specified in upcoming_course.yml
  deets = get_upcoming_deets()

  # Construct filename from details and course name
  glue::glue("{deets$course_date} [{deets$client_id}] {course_name}")
}

#' Get id of client delivery folder, creating it if it doesn't exist
#'
#' @importFrom glue glue
#' @importFrom googledrive as_id drive_ls drive_mkdir
#' @rdname create_gdoc
get_client_dir_id = function() {

  # Location of client training delivery folder (from suffix in drive url)
  client_parent_id = googledrive::as_id("1efi9SnQ7e0LSPToJI3cmTw-Gy6ZseOV0")
  # List all existing client directories
  client_dirs = googledrive::drive_ls(client_parent_id, type = "folder")

  deets = get_upcoming_deets()
  # Get name of client's directory from upcoming_course.yml
  client_dir = glue::glue("[{deets$client_id}] {deets$client_name}")

  # If client_dir exists then grab it, otherwise make it
  if (client_dir %in% client_dirs$name) {
    client_dir_id = client_dirs[client_dirs$name == client_dir, "id"][[1]]
  } else {
    client_dir_id = googledrive::drive_mkdir(client_dir, client_parent_id)$id
  }

  googledrive::as_id(client_dir_id)
}

#' Simple wrapper around rmarkdown render
#'
#' @importFrom rmarkdown render
#' @export
#' @rdname create_gdoc
render_docx = function() {
  rmarkdown::render("index.Rmd",
                    output_format = "word_document",
                    params = get_upcoming_deets())
}

#' Ensure that the file is being uploaded from a jr.com user
#'
#' @importFrom googledrive drive_auth drive_user
#' @rdname create_gdoc
check_google_user = function() {
  # Authenticate against google drive
  googledrive::drive_auth()
  # Get the user authenticated as
  user = googledrive::drive_user()

  if (!endsWith(user$emailAddress, "@jumpingrivers.com")) {
    stop("Must authenticate with a jumpingrivers.com email address.")
  }
}

#' Upload index.docx to google drive
#'
#' @param public boolean, whether to make the document writable by any with
#' link, defaults to TRUE
#' @importFrom googledrive drive_upload drive_share
#' @export
#' @rdname create_gdoc
upload_docx = function(public = TRUE) {
  # Check we are authenticated as as jr.com user
  check_google_user()

  upload = googledrive::drive_upload("index.docx",
                                     name = construct_gdoc_filename(),
                                     overwrite = TRUE,
                                     type = "document",
                                     path = get_client_dir_id())

  # Set document to be writeable to anyone with the link (default)
  if (isTRUE(public)) {
    googledrive::drive_share(upload, role = "writer", type = "anyone")
  }

  web_link = upload$drive_resource[[1]]$webViewLink[1]
  glue::glue("\n\nDocument uploaded to: {web_link}")
  return(invisible(web_link))
}
