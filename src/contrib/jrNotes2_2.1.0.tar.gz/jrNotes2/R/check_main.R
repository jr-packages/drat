check_main = function() {
  if (!is_connected()) return(invisible(NULL))

  ## Needed for runner
  system2("git", args = c("fetch", "origin"))
  msg_start("Comparing to main")
  g = system2("git",
              args = c("rev-list --left-right --count origin/main...@"),
              stdout = TRUE)

  main_commits = strsplit(g, split = "\t")[[1]][1]

  if (main_commits > 0) {
    msg_error("Main ahead; git pull")
    stop()
  }
  msg_success("Up to date with main")
  return(invisible(NULL))
}
