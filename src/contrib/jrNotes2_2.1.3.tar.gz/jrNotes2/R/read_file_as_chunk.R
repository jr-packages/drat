#' read file as chunk
#'
#' This funciton is intended to read lines from an external
#' source file and use them as the source for a knitr/rmarkdown
#' chunk.
#'
#' Can be used in knitr code chunk with
#' ```{r code=read_file_as_chunk(file, lines)}```
#'
#' @param file the path to file containing source
#' @param lines if -1 (default) will use all lines from the source,
#' alternatively a vector of lines of source to include can be specified
#' for showing snippets of longer code examples.
#'
#'@export
read_file_as_chunk = function(file, lines = -1) {
  if (length(lines) == 1 && lines == -1) {
    src = paste(readLines(file), collapse = "\n")
  } else {
    src = readLines(file, max(lines))
    src = src[lines]
    src = paste(src, collapse = "\n")
  }
  src
}
