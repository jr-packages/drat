# jrNotes2 
<!-- badges: start -->
[![Build Status](https://api.travis-ci.org/jr-packages/jrNotes2.png?branch=main)](https://travis-ci.org/jr-packages/)
[![Codecov test coverage](https://codecov.io/gh/jr-packages/jrNotes2/branch/main/graph/badge.svg)](https://codecov.io/gh/jr-packages/jrNotes2?branch=main)
<!-- badges: end -->
---

Package for Jumping Rivers Notes

