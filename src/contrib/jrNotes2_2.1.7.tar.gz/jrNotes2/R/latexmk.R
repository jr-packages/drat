#' @title Call latexmk
#'
#' @param fname Latex file
#' Detects if the references.bib file contains entries and calls
#' bibtex appropriately.
#' @export
latexmk = function(fname) {
  if (!file.exists(fname)) return(invisible(NULL))

  log_fname = sub("\\.tex$", ".log", fname)
  cli::cli_alert_info(
   "A detailed log from LaTeX's compilation can be found in {log_fname}"
  )

  refs = readLines("references.bib")
  if (length(refs) > 2) {
    system2("latexmk", args = c("-quiet", "--xelatex", fname))
  } else {
    system2("latexmk", args = c("-quiet", "--xelatex", "-bibtex-", fname))

  }
  return(invisible(TRUE))
}
