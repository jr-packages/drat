tokenise = function() {
  msg_start("Creating tokens...tokenise()")
  notes_dir = file.path(get_root_dir(), "notes")
  fname = system.file("extdata", "extractor.tex",
                      package = "jrNotes2", mustWork = TRUE)

  file.copy(fname, to = file.path(notes_dir, "extractor.tex"), overwrite = TRUE)
  if (!file.exists(file.path(notes_dir, "index.tex"))) stop("Missing index.tex file")

  file.copy(file.path(notes_dir, "index.tex"),
            file.path(notes_dir, "extractor-tmp.tex"),
            overwrite = TRUE)

  extractor_aux = file.path(notes_dir, "extractor.aux")
  # Remove aux file from previous run (fixes hanging tokenise() bug)
  system2("rm", args = c("-f", extractor_aux))

  extractor_inputs = file.path(notes_dir, c("extractor", "extractor-tmp.tex"))
  system2("xelatex",
          args = glue::glue("'\\input {extractor_inputs[1]} \\input {extractor_inputs[2]}'"),
          stdout = FALSE)
  msg_success("Tokens created")
}

globalVariables("text")
read_tokens = function() {
  fname = file.path(get_root_dir(), "notes", "extractor.csv")
  tokens = utils::read.delim(fname, sep = "|",
                             header = FALSE,
                             col.names = c("X1", "X2", "X3"),
                             stringsAsFactors = FALSE)

  tibble::as_tibble(tokens)
}
