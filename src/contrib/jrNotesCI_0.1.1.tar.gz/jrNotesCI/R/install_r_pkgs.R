get_r_pkg_names = function() {
  dirs = list.files("r_pkgs", full.names = TRUE)
  if (length(dirs) == 0L) return(invisible(NULL))
  cli::cli_alert_info("Found {length(dirs)} in r_pkgs...installing pkg + imports/suggests")
  sapply(dirs, function(i) remotes::install_local(i, dependencies = TRUE, build_vignettes = TRUE))

  des = file.path(dirs, "DESCRIPTION")
  pkg_names = sapply(des, function(i) read.dcf(i)[, "Package"])
  as.vector(pkg_names)
}

#' @rdname apt_update
#' @export
r_install = function(update = TRUE) {
  cli::cli_h2("Installing R packages")
  if (isTRUE(update)) {
    remotes::update_packages()
  }
  r_pkgs = yaml::read_yaml("config.yml")$r_pkgs
  if (is.null(r_pkgs)) {
    cli::cli_alert_info("No R pkgs found")
  }
  local_r_pkgs = get_r_pkg_names()
  r_pkgs = r_pkgs[!(r_pkgs %in% local_r_pkgs)]
  # Ignores NULLS
  remotes::install_cran(r_pkgs, dependencies = TRUE)
  return(invisible(c(local_r_pkgs, r_pkgs)))
}
