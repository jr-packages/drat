
copy_file = function(type, website_name) {
  root = get_root_dir()
  notes_website_dir = file.path(root, "website")
  notes = file.path(notes_website_dir, paste0(type, ".md"))
  website = file.path(root,
                      "website-brand",
                      "content/course-details/", type, paste0(website_name, ".md"))
  if (!file.exists(notes) || !file.exists(website)) stop()
  fs::file_copy(notes, website, overwrite = TRUE)
}

## Updates index.md in the Notes repo.
update_index = function() {
  cli::cli_alert_info("Updating index file")
  root = get_root_dir()
  ## Read in current index.md
  con = yaml::read_yaml(file.path(root, "config.yml"))
  website_name = con$website$name

  if (is.null(website_name)) {
    message("No website name found")
    return(invisible(NULL))
  }

  notes_website_dir = file.path(root, "website")
  (notes_materials = list.files(file.path(notes_website_dir, "materials")))
  if (length(notes_materials) == 0) {
    cli::cli_alert_warning("No material pngs found")
    return()
  }

  index_md_path = file.path(notes_website_dir, "index.md")
  index_md = readr::read_lines(index_md_path)

  images = stringr::str_detect(index_md, "^  images:")
  if (all(!images)) {
    cli::cli_alert_warning("No image section detected in index.md - adding one now")
    end = which(stringr::str_detect(index_md, "---"))[2] - 1
    new_lines = c("materials:", "  images:", "    - ", "")
    index_md = c(index_md[1:end], new_lines, index_md[(end + 1):length(index_md)])
    images = stringr::str_detect(index_md, "^  images:")
  }
  images_line_number = which(images)
  images = stringr::str_detect(index_md[(images_line_number + 1):(length(index_md))], "^    - ")

  # Find the line after the images
  to_start = images_line_number + which(!images)[1]
  new_index_lines = file.path("/course-details/materials", website_name, notes_materials)
  new_index_lines = paste0('    - "', new_index_lines, '"')
  new_index = c(index_md[1:images_line_number],
                new_index_lines,
                index_md[to_start:length(index_md)])
  if (new_index[length(new_index)] != "") new_index = c(new_index, "")

  readr::write_lines(new_index, index_md_path)
  cli::cli_alert_info("Index file updated {index_md_path}")
}



#' Update the course website pages
#'
#' This function is run on a notes repo.
#' It creates a branch on brand/website and pushes the changes
#' @export
update_website = function() {
  root = get_root_dir()
  con = yaml::read_yaml(file.path(root, "config.yml"))
  if (isFALSE(con$website$publish)) {
    cli::cli_alert_info("Publish is set to FALSE in config.")
    return(invisible(NULL))
  }
  website_name = con$website$name
  if (is.null(website_name)) {
    cli::cli_alert_info("No website name found")
    return(invisible(NULL))
  }

  cli::cli_alert_info("Update brand website")


  # index.md
  update_index()
  # Copy index.md over to the website
  website_brand_dir = file.path(root, "website-brand")
  website_path_index = file.path(website_brand_dir,
                           "content/training/course",
                           paste0(website_name, ".md"))

  notes_website_dir = file.path(root, "website")
  notes_path_index = file.path(notes_website_dir, "index.md")
  if (!(file.exists(notes_path_index) && file.exists(website_path_index))) {
    cli::cli_alert_danger("Can't find directories")
    stop()
  }

  fs::file_copy(notes_path_index, website_path_index, overwrite = TRUE)

  # Course feedback
  copy_file("attendee-feedback", website_name)
  copy_file("course-outline", website_name)
  copy_file("learning-outcomes", website_name)
  copy_file("prior-knowledge", website_name)

  # Materials
  website_materials_dir = file.path(website_brand_dir, "content/course-details/materials/",
                                    website_name)
  (website_materials = list.files(website_materials_dir, full.names = TRUE))
  fs::file_delete(website_materials)

  (notes_materials = list.files(file.path(notes_website_dir, "materials"), full.names = TRUE))
  fs::dir_create(website_materials_dir)
  fs::file_copy(notes_materials, website_materials_dir)
  return(invisible(NULL))
}
