git init drat
cd drat
git config user.name "Jumping Rivers"
git config user.email "drat@jumpingrivers.com"
git config --global push.default simple
git remote add upstream "https://$GITHUB_PAT@github.com/jr-packages/drat.git"
echo "Fetching Repo"
git fetch --depth 1 upstream
git checkout gh-pages
Rscript -e "pkgs = list.files('$CI_PROJECT_DIR/r_pkgs_tar', pattern='*.tar.gz', full.names = TRUE)
            drat::insertPackages(pkgs, repodir = '.', commit = 'GitLab CI - $CI_COMMIT_REF_SLUG')"
echo "Pushing to remote"
git push
echo "Cleaning up"
rm -fvr drat
