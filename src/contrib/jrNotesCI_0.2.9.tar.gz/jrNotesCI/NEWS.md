# jrNotesCI 0.2.9 _2021-07-20_
  * Feature: Install pip packages from config

# jrNotesCI 0.2.8 _2021-07-20_
  * Always get the root directory for config.yml. 
  This should also fix a bug in the current CI.

# jrNotesCI 0.2.7 _2021-06-11_
  * Bug: Force copy when image files exist

# jrNotesCI 0.2.6 _2021-05-21_
  * Bug: Force just page 1 from index.pdf
  * Bug: Set materials to be created only if index.pdf is present
  
# jrNotesCI 0.2.5 _2021-03-11_
  * Bug: Edit `update_website()` to allow copying of files that don't exist in corporate

# jrNotesCI 0.2.4 _2021-03-11_
  * Bug: Export `update_website()`

# jrNotesCI 0.2.2 _2021-03-03_
  * Feature: Add `update_website()` function
  * Internal: Move python pkg functions to {jrNotes2}
  * Internal: Remove pip packages. Now just python_pkgs
  * Bug: `get_root_dir()`
  * Feat: Install local python packages in the CI
  * Feat: check package versions
  * Initialise
