# jrNotes 
[![Build Status](https://api.travis-ci.org/jr-packages/jrNotes.png?branch=master)](https://travis-ci.org/jr-packages/)
---

Package for Jumping Rivers Notes

