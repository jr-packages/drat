# jrOOP 0.1.1 _2020-12-03_

  * Add NEWS.md
  * Change pkg title
  * Setting ALLOWED_NOTES=2 to bypass "All declared Imports should be used"
  * Modify .gitignore
