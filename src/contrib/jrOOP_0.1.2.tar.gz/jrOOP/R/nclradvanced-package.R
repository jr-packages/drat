#' R courses by Jumping Rivers
#'
#' Functions and datasets used in for R
#' courses by Jumping Rivers. This package is used in
#' the "Advanced R programming" course".
#' @name jrAdvanced-package
#' @importFrom pryr mem_used
#' @aliases jrAdvanced jrAdvanced
#' @docType package
#' @keywords package
NULL
