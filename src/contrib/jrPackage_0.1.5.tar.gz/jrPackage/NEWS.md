# jrPackage 0.1.5 _2020-11-26_
  * Add NEWS.md
  * Update pkg title
