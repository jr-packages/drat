#' R courses by Jumping Rivers
#' 
#' Functions and datasets used in for R 
#' courses run by Jumping Rivers. This package is used in
#' the "Building a package" course".
#' @name jrPackage-package
#' @aliases jrPackage
#' @docType package
#' @keywords package
NULL
