#' Predictive analytics
#'
#' Functions and datasets used for the predictive analytics
#' course by Jumping Rivers.
#' @name jrPredictive-package
#' @aliases jrPredictive
#' @docType package
#' @keywords package
NULL
