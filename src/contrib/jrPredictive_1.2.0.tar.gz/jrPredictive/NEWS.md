# jrPredictive 1.2.0 _2020-10-07_
  * Update: package title
