## Notes

 * The assets folder should only contain images from the package, not other presentation images. This will allow
 us to implement an upgrade script.
 * Ditto for the css file. Any changes should be made to `user.css` or as a PR.