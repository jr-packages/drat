# jrProgBio
[![Build Status](https://api.travis-ci.org/jr-packages/jrProgBio.png?branch=master)](https://travis-ci.org/jr-packages/jrProgBio)

Biology focussed programming for the Crick Institute

