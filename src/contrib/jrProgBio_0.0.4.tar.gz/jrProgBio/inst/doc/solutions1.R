## ----echo=FALSE---------------------------------
library(tufte)
# knitr::opts_chunk$set(results = "hide", echo = FALSE

## ----results="hide", echo=TRUE------------------
bases = c("C", "G", "A", "T")
sequence = ""
for (i in 1:9) {
  sequence = paste0(sequence, sample(bases, 1))
}
sequence

## -----------------------------------------------
sequence = ""
for (i in 1:15) {
  sequence = paste0(sequence, sample(bases, 1))
}
sequence

## -----------------------------------------------
bases = c("C", "G", "A", "U")
sequence = ""
for (i in 1:9) {
  sequence = paste0(sequence, sample(bases, 1))
}
sequence

## -----------------------------------------------
paste(sample(bases, 15, replace = TRUE), collapse = "")

## ----echo=TRUE----------------------------------
dd = data.frame(x = rnorm(10), y = rnorm(10), z = rnorm(10))

max_cols = numeric(ncol(dd))
for (i in seq_along(dd)) {
  max_cols[i] = max(dd[, i])
}
max_cols

## -----------------------------------------------
means = numeric(ncol(dd))
sds = numeric(ncol(dd))
for (i in seq_along(dd)) {
  means[i] = mean(dd[, i])
  sds[i] = sd(dd[, i])
}

## ----eval=FALSE, echo=TRUE----------------------
#  vignette("solutions1", package = "jrProgBio")

