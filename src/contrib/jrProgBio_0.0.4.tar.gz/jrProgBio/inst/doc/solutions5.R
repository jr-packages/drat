## ----include = FALSE----------------------------
knitr::opts_chunk$set(results = "show", echo = TRUE)

## ---- include = FALSE, cache = FALSE------------
library(knitr)
# opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

options(replace.assign = FALSE, width = 50)

opts_chunk$set(fig.path = "figure/graphics-",
               cache.path = "cache/graphics-",
               fig.align = "center",
               fig.width = 4, fig.height = 4,
               fig.show = "hold", cache = FALSE, par = TRUE)
knit_hooks$set(crop = hook_pdfcrop)

## ----echo=TRUE----------------------------------
data(malaria, package = "jrProgBio")
head(malaria)

## ----F1, echo=TRUE, eval=TRUE, tidy=FALSE, message=FALSE, fig.keep="none"----
library("dplyr")
library("ggplot2")
treat_a = filter(malaria, Temperature == 21)
ggplot(treat_a, aes(x = Day, y = Sporozoite_Prevalence)) +
  geom_point()

## ----results='hide', tidy=FALSE, echo = TRUE, eval=FALSE----
#  for (temp in unique(malaria$Temperature)) {
#    group = filter(malaria, Temperature == temp)
#    g = ggplot(group, aes(x = Day, y = Sporozoite_Prevalence)) +
#      geom_point()
#    print(g)
#    readline("Hit return for next plot")
#  }

## -----------------------------------------------
## It gives all temperatures

## -----------------------------------------------
## The Temperature variable is changing.
## It goes through the different temps.

## -----------------------------------------------
## It halts execution, waits for user input

## ----fig.keep='none', tidy=FALSE, echo=TRUE, eval=FALSE----
#  ggplot(group, aes(x = Day, y = Sporozoite_Prevalence)) +
#    geom_point() +
#    xlab("Day")

## ---- fig.keep="none", eval=FALSE---------------
#  ggplot(group, aes(x = Day, y = Sporozoite_Prevalence)) +
#    geom_point() +
#    xlab("Day") +
#    ylab("Sporozoite Prevalence")

## ----F2, tidy=FALSE, fig.keep="none", eval=FALSE, echo=TRUE----
#  ggplot(group, aes(x = Day, y = Sporozoite_Prevalence)) +
#    geom_point() +
#    xlab("Day") +
#    ylab("Sporozoite Prevalence") +
#    ggtitle("Temperature")

## ---- eval=FALSE, echo=TRUE---------------------
#  paste("Temperature", temp)

## ----fig.keep='none', tidy=FALSE, eval=FALSE----
#  ggplot(group, aes(x = Day, y = Sporozoite_Prevalence)) +
#    geom_point() +
#    xlab("Day") +
#    ylab("Sporozoite Prevalence") +
#    ggtitle(paste("Temperature :", temp))

## ----fig.keep='none', tidy=FALSE, eval=FALSE----
#  ylims = range(malaria$Sporozoite_Prevalence)
#  xlims = range(malaria$Day)
#  
#  ggplot(group, aes(x = Day, y = Sporozoite_Prevalence)) +
#    geom_point() +
#    xlab("Day") +
#    ylab("Sporozoite Prevalence") +
#    ggtitle(paste("Temperature :", temp)) +
#    xlim(xlims[1], xlims[2]) +
#    ylim(ylims[1], ylims[2])

## ---- fig.keep='none', tidy=FALSE, eval=FALSE----
#  ggplot(group, aes(x = Day, y = Sporozoite_Prevalence,
#                    colour = factor(Block))) +
#    geom_point() +
#    xlab("Day") +
#    ylab("Sporozoite Prevalence") +
#    ggtitle(paste("Temperature :", temp)) +
#    xlim(xlims[1], xlims[2]) +
#    ylim(ylims[1], ylims[2])

## ---- fig.keep='none', tidy=FALSE, eval=FALSE----
#  ggplot(group, aes(x = Day, y = Sporozoite_Prevalence,
#                    colour = factor(Block))) +
#    geom_point() +
#    geom_line(aes(group = interaction(Block, Cup))) +
#    xlab("Day") +
#    ylab("Sporozoite Prevalence") +
#    ggtitle(paste("Temperature :", temp)) +
#    xlim(xlims[1], xlims[2]) +
#    ylim(ylims[1], ylims[2])

## ----message=FALSE, tidy=FALSE, echo=FALSE, eval=TRUE, fig.height=3----
temp = 34
group = filter(malaria, Temperature == temp)
ylims = range(malaria$Sporozoite_Prevalence)
xlims = range(malaria$Day)
ggplot(group, aes(x = Day, y = Sporozoite_Prevalence,
                  colour = factor(Block))) +
  geom_point() +
  geom_line(aes(group = interaction(Block, Cup))) +
  xlab("Day") +
  ylab("Sporozoite Prevalence") +
  ggtitle(paste("Temperature :", temp)) +
  xlim(xlims[1], xlims[2]) +
  ylim(ylims[1], ylims[2])

## ---- eval=FALSE, echo=TRUE---------------------
#  # decide on a filename and path
#  filename = "my_awesome_figure.pdf"
#  pdf(filename)
#  
#  # do your plotting
#  
#  # close the connection to the file
#  dev.off()

## ----eval=FALSE, echo=TRUE----------------------
#  vignette("solutions5", package = "jrProgBio")

## ----message=FALSE, tidy=FALSE, eval=FALSE------
#  ## FULL SOLUTION
#  viewgraphs = function(malaria, save=FALSE, filename = "graphs.pdf") {
#  
#    if (save) {
#      pdf(filename)
#    }
#  
#    ylims = range(malaria$Sporozoite_Prevalence)
#    xlims = range(malaria$Day)
#  
#    for (temp in unique(malaria$Temperature)) {
#  
#      group = filter(malaria, Temperature == temp)
#  
#      g = ggplot(group, aes(x = Day, y = Sporozoite_Prevalence,
#                            colour = factor(Block))) +
#        geom_point() +
#        geom_line(aes(group = interaction(Block, Cup))) +
#        xlab("Day") +
#        ylab("Sporozoite Prevalence") +
#        ggtitle(paste("Temperature :", temp)) +
#        xlim(xlims[1], xlims[2]) +
#        ylim(ylims[1], ylims[2])
#      print(g)
#    }
#  
#    if (save) {
#      dev.off()
#    }
#  
#  }

