# jrProgramming 0.3.0 _2020-09-02_

  * Update course package name to match notes

# jrProgramming 0.2.9 _2020-08-10_

  * Update Practical 1 Q1
