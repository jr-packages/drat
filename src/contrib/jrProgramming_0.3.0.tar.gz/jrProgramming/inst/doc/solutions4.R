## ----include = FALSE--------------------------------------
knitr::opts_chunk$set(results = "show", echo = TRUE)

## ---- echo = TRUE-----------------------------------------
create_workflow = function(project_name) {
  dir.create(project_name)
}

## ---- echo = TRUE-----------------------------------------
file.path("project", "directory")

## ---------------------------------------------------------
create_workflow = function(project_name) {
  dir.create(project_name)
    for (directory in c("input", "R", "graphics", "output")) {
    dir.create(path = file.path(project_name, directory))
  }
}

## ---- eval = FALSE, echo = TRUE---------------------------
#  file.create("load.R")

## ---------------------------------------------------------
create_workflow = function(project_name) {
  dir.create(path = project_name)
  for (directory in c("input", "R", "graphics", "output")) {
    dir.create(path = file.path(project_name, directory))
  }
  for (rfile in c("load", "clean", "func", "do", "graphics")) {
    fname = paste0(rfile, ".R")
    fpath = file.path(project_name, "R", fname)
    file.create(fpath)
  }
}

## ---- eval = FALSE, echo = TRUE---------------------------
#  file.create("clean.R")
#  file_conn = file("clean.R")
#  writeLines("source('load.R')", file_conn)
#  close(file_conn)

## ---------------------------------------------------------
create_workflow = function(project_name) {
  dir.create(path = project_name)
  for (directory in c("input", "R", "graphics", "output")) {
    dir.create(path = file.path(project_name, directory))
  }
  for (rfile in c("load", "clean", "func", "do", "graphics")) {
    fname = paste0(rfile, ".R")
    fpath = file.path(project_name, "R", fname)
    file.create(fpath)
    if (exists("code")) {
      print(exists("code"))
      file_conn = file(fpath)
      writeLines(code, file_conn)
      close(file_conn)
    }
    code = paste0('source("', fpath, '")')
  }
}

## ----eval=FALSE, echo=TRUE--------------------------------
#  vignette("solutions4", package = "jrProgramming")

