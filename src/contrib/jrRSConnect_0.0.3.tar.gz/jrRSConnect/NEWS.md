# jrRSConnect 0.0.3 _2020-10-29_

  * Internal: Pass InteRgrate checks
