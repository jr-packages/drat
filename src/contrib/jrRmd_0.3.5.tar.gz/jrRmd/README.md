# jrRmd
[![Build Status](https://api.travis-ci.org/jr-packages/jrRmd.png?branch=master)](https://travis-ci.org/jr-packages/)
Package for the jrrmarkdown_notes repo
