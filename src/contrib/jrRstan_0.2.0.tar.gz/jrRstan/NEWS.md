# jrRstan 0.2.0 _2020-10-15_
  * Initialise
