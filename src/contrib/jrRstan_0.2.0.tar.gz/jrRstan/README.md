# Introduction to Bayesian inference using RStan
[![Build Status](https://api.travis-ci.com/jr-packages/jrStan.png?branch=master)](https://travis-ci.com/jr-packages/jrRstan)

Course material for the [Introduction to Stan](www.jumpingrivers.com) course. 
