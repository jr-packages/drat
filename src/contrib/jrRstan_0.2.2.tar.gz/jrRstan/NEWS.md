# jrRstan 0.2.2 _2021-08-23_
  * {stanhl} now contained within this package (RSPM bug)
  * Moved {Rdpack} to depends (for R CMD check)

# jrRstan 0.2.1 _2020-10-23_
  * Suggest jr-packages/stanhl package for stan syntax highlighting

# jrRstan 0.2.0 _2020-10-15_
  * Initialise
