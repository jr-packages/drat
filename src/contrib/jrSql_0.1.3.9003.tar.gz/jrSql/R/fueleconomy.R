#' Fuel economy data
#'
#' @name cars2010
#' @docType data
NULL

#' Fuel Economy data
#'
#' @name cars2011
#' @docType data
NULL

#' Fuel Economy data
#'
#' @name cars2012
#' @docType data
NULL
