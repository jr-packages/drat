add_tables = function(user, host = host,
                      password = user,
                      dbname = user, port = 5432) {
  message("Adding tables to database for user ", user)
  con = DBI::dbConnect(DBI::dbDriver("PostgreSQL"),
                       host = host,
                       user = user,
                       password = password,
                       dbname = dbname, port = port)
  on.exit(DBI::dbDisconnect(con))

  e = new.env()
  data(diamonds, package = "ggplot2", envir = e)
  dplyr::copy_to(con, e$diamonds, name = "diamonds", overwrite = TRUE,
                 temporary = FALSE)
  data(movies, package = "ggplot2movies", envir = e)
  dplyr::copy_to(con, e$movies, name = "movies", overwrite = TRUE,
                 temporary = FALSE)
}

create_user = function(con, user) {
  force(user)
  pass = dbname = user
  message("Creating user on database: ", user);
  query = c(
    paste0("create database ", dbname, ";"),
    paste0("revoke connect on database ", dbname, " from public;"),
    paste0("create user ", user, " with encrypted password '", pass, "';"),
    paste0("grant all privileges on database ", dbname, " to ", user, ";")
  )
  purrr::map(query, ~DBI::dbExecute(con, .x))
  add_tables(user, pass, dbname)
}

#' Create users on the server
#'
#' This function creates a database per user.
#' Each user will have identical databases, called `user`.
#' The username and passowrd are also set to `user`, where user
#' is the username, e.g. u010
#' @param password The (root) password. Needed to create users
#' @param n Number of users - u001 to un
#' @param host,user,dbname,port Standard dbConnect arguments
#' @export
create_many_users = function(password, n = 50,
                             host = "localhost", user = "postgres-user",
                             dbname = "postgres-database", port = 5432) {
  # Creates a connect to the root(?) database to create users
  con = dbConnect(DBI::dbDriver("PostgreSQL"), host = host, user = user,
                  password = password, port = port, dbname = dbname)
  on.exit(DBI::dbDisconnect(con))
  for (user in sprintf("u%03d", 1:n)) {
    tryCatch(create_user(con, user), error = function(e) {
      print(e)
    })
  }
  return(invisible(NULL))
}
