#' Details of 14694 music singles from between 1950 and 2019
#'
#' From Moura, Luan; Fontelles, Emanuel; Sampaio, Vinicius; França, Mardônio (2020), “Music Dataset:
#' Lyrics and Metadata from 1950 to 2019”, Mendeley Data, V3, doi: 10.17632/3t9vbwxgr5.3
#'
#' Obtained from kaggle.com (dataset: "saurabhshahane/music-dataset-1950-to-2019")
#'
#' Filtered to keep only songs with (obscene < 0.125 and violence < 0.125).
#' Kept the columns ("artist_name", "track_name", "release_date", "genre", "lyrics", "topic",
#' "age").
#'
#' @format   A data frame with 14694 rows and 7 columns
#'
#' @source   \url{https://www.kaggle.com/saurabhshahane/music-dataset-1950-to-2019}
"music"
