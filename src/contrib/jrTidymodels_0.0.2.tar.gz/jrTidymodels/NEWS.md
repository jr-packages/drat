# jrTidymodels 0.0.2 _2020-09-16_
  * Add tibble pkg to Imports

# jrTidymodels 0.0.1 _2020-09-16_
  * Initial pkg template
  * Add NEWS.md
