# jrTidymodels 0.1.3 _2020-11-10_
  * Add india and gapminder data

# jrTidymodels 0.1.2 _2020-11-10_
  * Add glmnet to Imports

# jrTidymodels 0.1.1 _2020-11-09_
  * Add several dependencies for jrTidymodels2_notes

# jrTidymodels 0.1.0 _2020-09-30_
  * Convert advertising data from data frame to tibble
  * Add system packages
  * Covert Default package to a tibble + add default_numeric row
  * Add new Default data in \data and document in default.R
  * Add code to generate new Default data to \inst

# jrTidymodels 0.0.* _2020-09-17_ 
  * Fix kknn pkg problem
  * Add e1071 pkg to Suggests
  * Add caret pkg to Imports
  * Add mixture_example data
  * Add boundary_plot.R
  * Add mixture_example.R
  * Update Dockerfile
  * Add tibble pkg to Imports
  * Initial pkg template
  * Add NEWS.md
