# jrTimeSeries 0.0.1 _2020-12-02_
  * Initial pkg template
