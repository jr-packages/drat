#' Movies data
#'
#' Some data for the workshop
#'
#'@name movies
#'@docType data
#'@usage data(movies)
#'@return A tibble
#'@keywords datasets
#'@examples
#' data(movies)
NULL

#' okcupid data
#'
#' Some data for the workshop
#'
#'@name okcupid
#'@docType data
#'@usage data(okcupid)
#'@return A tibble
#'@keywords datasets
#'@examples
#' data(okcupid)
NULL
