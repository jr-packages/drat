## ----include = FALSE----------------------------------------------------------
library(tufte)
knitr::opts_chunk$set()

## ---- message=FALSE-----------------------------------------------------------
library(shiny)
data(movies, package = "jrYr")

## ---- eval = FALSE, cache=FALSE-----------------------------------------------
#  selectInput(inputId = "movie_type", # unique id
#              label = "Movie genre", # Text for web
#              choices = c("romance", "action", "thriller"),
#              selected = "action")

## ---- eval = FALSE, cache=FALSE-----------------------------------------------
#  sliderInput(inputId = "movie_rating",
#              label = "Movie rating",
#              min = 0, max = 10, value = 5)

## ---- eval = FALSE, cache=FALSE-----------------------------------------------
#  numericInput(inputId = "movie_length",
#               label = "Movie length",
#               min = 1, max = 330, value = 100)

## ----eval=FALSE, cache=FALSE--------------------------------------------------
#  renderText(input$movie_type)

## ----eval=FALSE, cache=FALSE--------------------------------------------------
#  renderText({
#    type = movies[, input$movie_type] == 1
#    nrow(movies[type, ])
#  })

## ----eval=FALSE, cache=FALSE--------------------------------------------------
#  renderPlot({
#    type = movies[, input$movie_type] == 1
#    hist(movies[type, ]$length)
#  })

## ---- eval = FALSE, cache=FALSE-----------------------------------------------
#  selectInput(inputId = "movie_type",
#              label = "Movie classification",
#              choices = c("U", "PG", "12A", "15", "18"),
#              selected = "12A")

## ----eval = FALSE, cache=FALSE------------------------------------------------
#  data(movies, package = "jrYr")
#  pg_movies = movies[movies$classification == "PG", ]
#  nrow(pg_movies)

## ----eval=FALSE, cache=FALSE--------------------------------------------------
#  renderText({
#    type = movies[, input$movie_type] == 1
#    nrow(movies[type, ])
#  })
#  
#  renderPlot({
#    type = movies[, input$movie_type] == 1
#    hist(movies[type, ]$length)
#  })

## ----eval=FALSE, cache=FALSE--------------------------------------------------
#  rvs = reactiveValues(data = movies)

## ---- eval = FALSE, cache=FALSE-----------------------------------------------
#  observe({
#      type = movies[, input$movie_type] == 1
#      rvs$data = movies[type, ]
#  })

## ---- eval = FALSE, cache=FALSE-----------------------------------------------
#  rvs = reactiveValues(data = movies)
#  
#  observe({
#    type = movies[, input$movie_type] == 1
#    rvs$data = movies[type, ]
#  })
#  
#  renderText({
#    nrow(rvs$data)
#  })
#  
#  renderPlot({
#    hist(rvs$data$length)
#  })

## ---- eval = FALSE, cache=FALSE-----------------------------------------------
#  rvs = reactiveValues(data = movies)
#  
#  actionButton("plot_button", "Plot it now!!!")
#  
#  observeEvent(input$plot, {
#    type = movies[, input$movie_type] == 1
#    rvs$data = movies[type, ]
#  })
#  
#  renderPlot({
#    hist(rvs$data$length)
#  })

## ---- eval = FALSE, cache=FALSE-----------------------------------------------
#  library("ggplot2")
#  data(movies, package = "jrYr")
#  g = ggplot(movies, aes(x = length, y = rating)) +
#    geom_point()
#  g

## ---- eval = FALSE, cache=FALSE-----------------------------------------------
#  library("plotly")
#  ggplotly(g)

## ---- eval = FALSE, cache=FALSE-----------------------------------------------
#  library("ggplot2")
#  library("plotly")
#  data(movies, package = "jrYr")
#  selectInput(inputId = "movie_type",
#              label = "Movie genre",
#              choices = c("romance", "action", "thriller"))
#  rvs = reactiveValues(data = movies)
#  
#  observe({
#    type = movies[, input$movie_type] == 1
#    rvs$data = movies[type, ]
#  })
#  
#  renderPlotly({
#    ggplotly(ggplot(rvs$data, aes(x = length)) +
#      geom_histogram())
#  })

## ---- eval = FALSE, message=FALSE, warning = FALSE, cache=FALSE---------------
#  library("DT")
#  datatable(movies)

## ---- eval = FALSE, results = "hide", message=FALSE, warning = FALSE, cache=FALSE----
#  library("ggplot2")
#  library("plotly")
#  library("DT")
#  data(movies, package = "jrYr")
#  selectInput(inputId = "movie_type",
#              label = "Movie genre",
#              choices = c("romance", "action", "thriller"))
#  rvs = reactiveValues(data = movies)
#  observeEvent(input$movie_type, {
#    rvs$data = movies[movies[, input$movie_type] == 1, ]
#  })
#  renderDataTable({
#    datatable(rvs$data[, 1:5])
#  })

## ----eval = FALSE, results="hide", cache=FALSE, message=FALSE-----------------
#  library("shiny")
#  fluidPage(
#    titlePanel("Shiny happy people"), #title
#    ## Sidebar with a slider input for no. of points
#    sidebarLayout(
#      sidebarPanel(
#        selectInput(inputId = "movie_type", # unique id
#                    label = "Movie genre", # Text for web
#                    choices = c("romance", "action", "thriller"),
#                    selected = "action")
#      ),
#      ## Show a plot of the generated distribution
#      mainPanel(plotOutput("scatter"))
#    )
#  )

## ----results="hide", message=FALSE,eval = FALSE, cache=FALSE------------------
#  library("shiny")
#  data(movies, package = "jrYr")
#  
#  # Function always has input & output
#  function(input, output) {
#    rvs = reactiveValues(data = movies)
#  
#    observeEvent(input$movie_type, {
#      rvs$data = movies[movies[, input$movie_type] == 1, ]
#    })
#  
#    output$scatter = renderPlot({
#      plot(x = rvs$data$duration, y = rvs$data$rating)
#    })
#  
#  }

## ----results="hide", cache=FALSE,eval = FALSE---------------------------------
#  fluidPage(
#    titlePanel("Title panel"), # Title
#    ## Sidebar style
#    sidebarLayout(
#      sidebarPanel("The sidebar"),
#      mainPanel("Main panel")
#    )
#  )

## ----results="hide", cache=FALSE,eval = FALSE---------------------------------
#  sidebarLayout(position = "right",
#    sidebarPanel("The sidebar"),
#    mainPanel("Main panel")
#  )

## ----results="hide",eval = FALSE, cache=FALSE---------------------------------
#  sidebarLayout(
#    sidebarPanel("The sidebar", p("Choose an option")),
#    mainPanel("Main panel")
#  )

## ----cache=FALSE,eval = FALSE-------------------------------------------------
#  ui = fluidPage(
#    titlePanel("I love movies"), #Title
#    fluidRow(# Define a row
#      column(4, # Two columns: width 4 & 8
#             wellPanel(
#               selectInput("movie_type", label = "Movie genre",
#                           c("Romance", "Action", "Animation"))
#             )
#       ),
#      column(8, plotOutput("scatter"))
#    )
#  )

