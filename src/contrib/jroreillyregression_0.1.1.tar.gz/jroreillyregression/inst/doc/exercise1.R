## -----------------------------------------------------------------------------
library(jroreillyregression)
data(bond)
head(bond)

